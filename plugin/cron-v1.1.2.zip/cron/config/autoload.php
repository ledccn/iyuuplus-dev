<?php
return [
    'files' => [
        base_path() . '/plugin/cron/app/functions.php',
    ]
];