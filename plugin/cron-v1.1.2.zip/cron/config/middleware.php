<?php

return [
    '' => [

    ],
    'admin' => [
        plugin\admin\api\Middleware::class,
    ],
];
