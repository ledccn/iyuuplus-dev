<?php
/**
 * 子进程启动后onWorkerStart时执行
 */
return [
    plugin\cron\app\Bootstrap::class
];
